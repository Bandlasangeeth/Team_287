# from flask import Flask, render_template, request

# app = Flask(__name__)

# # Mock data for demonstration purposes
# industry_partners = ["Tech Mahindra", "Tata Motors", "L&T Construction"]
# career_paths = {
#     "Technology": ["VR Developer", "AI Specialist", "Software Engineer"],
#     "Automotive": ["Automotive Technician", "Design Engineer", "Manufacturing Specialist"],
#     "Construction": ["Civil Engineer", "Site Supervisor", "Construction Manager"],
# }

# # Mock data for digital badges
# digital_badges = {
#     "VR Developer": ["VR Design", "3D Modeling", "Scripting"],
#     "AI Specialist": ["Machine Learning", "Data Analysis", "Python Programming"],
#     "Software Engineer": ["Web Development", "Database Management", "Algorithm Design"],
#     "Automotive Technician": ["Engine Repair", "Electrical Systems", "Diagnostics"],
#     "Design Engineer": ["CAD Design", "Materials Science", "Prototyping"],
#     "Manufacturing Specialist": ["Lean Manufacturing", "Process Optimization", "Quality Control"],
#     "Civil Engineer": ["Structural Analysis", "Project Management", "Site Surveying"],
#     "Site Supervisor": ["Safety Management", "Resource Allocation", "Scheduling"],
#     "Construction Manager": ["Contract Administration", "Budgeting", "Risk Management"]
# }


# @app.route('/')
# def index():
#     return render_template('index.html', industry_partners=industry_partners, career_paths=career_paths)

# @app.route('/career_details', methods=['POST'])
# def career_details():
#     selected_career = request.form.get('career')
#     badges = digital_badges.get(selected_career, [])
#     return render_template('career_details.html', career=selected_career, badges=badges)

# if __name__ == '__main__':
#     app.run(debug=True)
from flask import Flask, render_template, request, redirect, url_for, flash, session

app = Flask(__name__)
app.secret_key = 'vocational_training_key'

# Mock data for demonstration purposes
industry_partners = ["Tech Mahindra", "Tata Motors", "L&T Construction"]
career_paths = {
    "Technology": ["VR Developer", "AI Specialist", "Software Engineer"],
    "Automotive": ["Automotive Technician", "Design Engineer", "Manufacturing Specialist"],
    "Construction": ["Civil Engineer", "Site Supervisor", "Construction Manager"],
}

# Mock data for digital badges
digital_badges = {
    "VR Developer": ["VR Design", "3D Modeling", "Scripting"],
    "AI Specialist": ["Machine Learning", "Data Analysis", "Python Programming"],
    "Software Engineer": ["Web Development", "Database Management", "Algorithm Design"],
    "Automotive Technician": ["Engine Repair", "Electrical Systems", "Diagnostics"],
    "Design Engineer": ["CAD Design", "Materials Science", "Prototyping"],
    "Manufacturing Specialist": ["Lean Manufacturing", "Process Optimization", "Quality Control"],
    "Civil Engineer": ["Structural Analysis", "Project Management", "Site Surveying"],
    "Site Supervisor": ["Safety Management", "Resource Allocation", "Scheduling"],
    "Construction Manager": ["Contract Administration", "Budgeting", "Risk Management"]
}

# Mock job listings data
job_listings = {
    "VR Developer": [
        {"company": "Tech Mahindra", "location": "Bangalore", "experience": "2-4 years"},
        {"company": "Infosys", "location": "Pune", "experience": "1-3 years"}
    ],
    "AI Specialist": [
        {"company": "Wipro", "location": "Hyderabad", "experience": "3-5 years"},
        {"company": "TCS", "location": "Mumbai", "experience": "2-4 years"}
    ]
}

# User progress tracking
user_progress = {}

@app.route('/')
def index():
    return render_template('index.html', industry_partners=industry_partners, career_paths=career_paths)

@app.route('/career_details', methods=['POST'])
def career_details():
    selected_career = request.form.get('career')
    badges = digital_badges.get(selected_career, [])
    jobs = job_listings.get(selected_career, [])
    return render_template('career_details.html', career=selected_career, badges=badges, jobs=jobs)

@app.route('/enroll', methods=['POST'])
def enroll():
    career = request.form.get('career')
    name = request.form.get('name')
    email = request.form.get('email')
    
    if not (career and name and email):
        flash('Please fill all fields')
        return redirect(url_for('index'))
    
    # Mock enrollment process - in a real app, this would save to a database
    flash(f'Successfully enrolled in {career} training program!')
    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        query = request.form.get('query', '').lower()
        results = []
        
        # Search through careers
        for industry, careers in career_paths.items():
            for career in careers:
                if query in career.lower():
                    results.append({
                        'type': 'Career',
                        'name': career,
                        'details': industry
                    })
        
        # Search through badges
        for career, badges in digital_badges.items():
            for badge in badges:
                if query in badge.lower():
                    results.append({
                        'type': 'Badge',
                        'name': badge,
                        'details': f'Part of {career} training'
                    })
                    
        return render_template('search_results.html', query=query, results=results)
    
    return render_template('search.html')

if __name__ == '__main__':
    app.run(debug=True)